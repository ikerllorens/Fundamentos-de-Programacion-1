// AreaRectangulo.c

//Creado por Iker Llorens el 5/09/12

#include <stdio.h>
int main(void)
{
  int base, altura, area;
  printf("Dame la base y altura en cms:");
  scanf("%d",&base);
  scanf("%d",&altura);
  area=base*altura;
  printf("\nEl área del rectángulo es: %d \n", area);
  printf("\nBE HAPPY!!!!!! :) \n");
    return 0;
}

//BE HAPPY!!!
